# OWASP findings, cited

**Project:** `K_DEERFLOW`  
**Tier:** TIER_4_INFERENCE_AGENTS  
**Identity:** Upstream `bytedance/deer-flow` @ `f75d89f39dd1` (MIT)

## Purpose

Third-party and published results, as-is.

## This project

| Fact | Value |
| --- | --- |
| Upstream | `bytedance/deer-flow` |
| Commit | `f75d89f39dd152873bf2b6486052644a77e830fb` |
| Upstream licence | MIT |
| Licence class | permissive |
| Clone size | 58.77 MB |
| Ledger | 0 blocks, chain verified |
| Current TRL | NOT YET MEASURED |
| Post-optimisation TRL | NOT YET MEASURED |
| II budget cap | 1000.0 IIU |
| Verified upstream edits | 1 |

## Known gaps

Everything above is read from an artifact. Where this document says
`NOT YET MEASURED`, the value has not been measured for `K_DEERFLOW` as of
generation. Filling those in requires a run or a decision, not editing.
